from django.contrib import admin
from workflow_manager.workflow_v2.models.workflow import Workflow

admin.site.register(Workflow)
