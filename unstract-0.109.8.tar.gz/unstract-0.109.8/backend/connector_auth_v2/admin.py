from django.contrib import admin

from .models import ConnectorAuth

admin.site.register(ConnectorAuth)
