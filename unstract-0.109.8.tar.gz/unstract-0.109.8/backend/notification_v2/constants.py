class NotificationUrlConstant:
    """Constants for Notification Urls."""

    PIPELINE_UID = "pipeline_uuid"
    API_UID = "api_uuid"
