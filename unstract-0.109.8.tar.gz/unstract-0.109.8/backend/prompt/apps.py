from django.apps import AppConfig


class PromptConfig(AppConfig):
    name = "prompt"
