from django.apps import AppConfig


class PipelineConfig(AppConfig):
    name = "pipeline_v2"
