from django.apps import AppConfig


class PromptStudioDocumentManagerConfig(AppConfig):
    name = "prompt_studio.prompt_studio_document_manager_v2"
