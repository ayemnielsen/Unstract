from django.apps import AppConfig


class PromptStudioRegistry(AppConfig):
    name = "prompt_studio.prompt_studio_registry_v2"
