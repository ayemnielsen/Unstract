class IndexManagerKeys:
    PROFILE_MANAGER = "profile_manager"
    DOCUMENT_MANAGER = "document_manager"
