from django.apps import AppConfig


class PromptStudioIndexManagerConfig(AppConfig):
    name = "prompt_studio.prompt_studio_index_manager_v2"
