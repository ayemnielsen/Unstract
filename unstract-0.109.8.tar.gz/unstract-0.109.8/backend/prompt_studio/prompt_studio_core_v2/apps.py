from django.apps import AppConfig


class CustomTool(AppConfig):
    name = "prompt_studio.prompt_studio_core_v2"
