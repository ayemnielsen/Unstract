from django.contrib import admin

from .models import CustomTool

admin.site.register(CustomTool)
