from django.apps import AppConfig


class PromptStudioOutputManager(AppConfig):
    name = "prompt_studio.prompt_studio_output_manager_v2"
