from django.contrib import admin

from .models import ToolStudioPrompt

admin.site.register(ToolStudioPrompt)
