import os


class V2:
    SCHEMA_NAME = os.getenv("DB_SCHEMA", None)
