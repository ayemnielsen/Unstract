from django.apps import AppConfig


class MigrationToolsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "migrating.v2"
