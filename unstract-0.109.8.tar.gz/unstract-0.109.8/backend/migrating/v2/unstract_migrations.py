from migrating.v2.query import MigrationQuery


class UnstractMigration(MigrationQuery):
    pass
