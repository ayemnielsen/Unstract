from django.contrib import admin

from .models import ConnectorInstance

admin.site.register(ConnectorInstance)
