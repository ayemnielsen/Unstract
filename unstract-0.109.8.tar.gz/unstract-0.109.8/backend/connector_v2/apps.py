from django.apps import AppConfig


class ConnectorConfig(AppConfig):
    name = "connector_v2"
