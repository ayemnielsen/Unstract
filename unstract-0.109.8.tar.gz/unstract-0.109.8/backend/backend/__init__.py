from .celery_service import app as celery_app

__all__ = ["celery_app"]
