from django.apps import AppConfig


class UsageConfig(AppConfig):
    name = "usage_v2"
