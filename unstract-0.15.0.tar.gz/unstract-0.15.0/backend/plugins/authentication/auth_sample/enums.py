from enum import Enum


class Region(Enum):
    US = "US"
    EU = "EU"
