from django.apps import AppConfig


class ToolInstanceConfig(AppConfig):
    name = "tool_instance"
