class LogServerConstants:
    USER_INFO="userinfo"
    PRIMARY_SUB="primary_sub"