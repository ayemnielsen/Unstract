# from . import views

urlpatterns = []  # type: ignore
