from django.apps import AppConfig


class TenantAccountConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "tenant_account"
