class CronKeys:
    CRON_STRING = "cron_string"
    FREQUENCY = "frequency"
    SUMMARY = "summary"
    # For caching
    CRON_CACHE_STATUS = "is_cleared"
    ORG_ID = "org_id"
