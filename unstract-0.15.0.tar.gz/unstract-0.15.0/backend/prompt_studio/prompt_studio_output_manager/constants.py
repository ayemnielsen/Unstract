class PromptStudioOutputManagerKeys:
    TOOL_ID = "tool_id"
    PROMPT_ID = "prompt_id"
    PROFILE_MANAGER = "profile_manager"
    DOC_NAME = "doc_name"
