from django.contrib import admin
from workflow_manager.workflow.models.workflow import Workflow

admin.site.register(Workflow)
