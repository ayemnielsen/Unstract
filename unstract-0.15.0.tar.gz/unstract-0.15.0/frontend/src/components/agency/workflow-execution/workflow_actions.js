const Actions = {
  START: "START",
  NEXT: "NEXT",
  STOP: "STOP",
  CONTINUE: "CONTINUE",
};

export default Actions;
