from django.apps import AppConfig


class ConnectorAuthConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "connector_auth"
