class ApiExecution:
    PATH: str = "deployment/api"
    MAXIMUM_TIMEOUT_IN_SEC: int = 300  # 5 minutes
