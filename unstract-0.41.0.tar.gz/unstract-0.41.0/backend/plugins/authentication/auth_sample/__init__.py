from .auth_service import AuthService

metadata = {
    "name": "sample_auth",
    "service_class": AuthService,
    "description": "Sample Authentication Method",
    "is_active": False,
}
