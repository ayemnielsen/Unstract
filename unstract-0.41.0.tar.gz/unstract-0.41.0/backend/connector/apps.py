from django.apps import AppConfig


class ConnectorConfig(AppConfig):
    name = "connector"
