class AppConstants:
    """Constants for Apps."""

   