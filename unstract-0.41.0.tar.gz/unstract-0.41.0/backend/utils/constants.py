class Account:
    CREATED_BY = "created_by"
    MODIFIED_BY = "modified_by"


class Common:
    METADATA = "metadata"
    MODULE = "module"
    CONNECTOR = "connector"
