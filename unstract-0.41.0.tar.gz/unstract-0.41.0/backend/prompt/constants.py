class PromptErrors:
    PROMPT_EXISTS = "Prompt with this configuration already exists"
    DUPLICATE_API = "It appears that a duplicate call may have been made."
