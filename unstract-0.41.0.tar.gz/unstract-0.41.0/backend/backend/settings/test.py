from backend.settings.base import *  # noqa: F401, F403

DEBUG = True
