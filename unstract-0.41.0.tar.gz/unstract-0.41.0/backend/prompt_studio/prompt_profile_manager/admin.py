from django.contrib import admin

from .models import ProfileManager

admin.site.register(ProfileManager)
