from django.apps import AppConfig


class ProfileManager(AppConfig):
    name = "prompt_studio.prompt_profile_manager"
