from django.contrib import admin

from .models import DocumentManager

admin.site.register(DocumentManager)
