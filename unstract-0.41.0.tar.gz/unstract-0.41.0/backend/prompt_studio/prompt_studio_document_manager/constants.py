class PSDMKeys:
    DOCUMENT_NAME = "document_name"
    TOOL = "tool"
    DOCUMENT_ID = "document_id"
