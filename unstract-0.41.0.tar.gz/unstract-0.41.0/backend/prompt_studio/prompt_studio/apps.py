from django.apps import AppConfig


class ToolStudioPrompt(AppConfig):
    name = "prompt_studio.prompt_studio"
